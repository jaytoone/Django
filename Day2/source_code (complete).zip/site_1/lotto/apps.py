from django.apps import AppConfig


class LottoConfig(AppConfig):
    name = 'lotto'
