from django.contrib import admin
from .models import GuessNumbers

# Register your models here.
admin.site.register(GuessNumbers)
